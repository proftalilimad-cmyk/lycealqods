عروض PowerPoint قابلة للتحرير في Keynote
المستوى: الأولى باكالوريا
عدد العروض: 33

المحتوى مبني على دروس الموقع الأصلي. افتح ملفات .pptx في Microsoft PowerPoint أو Apple Keynote.
